Lucifer Donghua Synthetiq module — experimental
Source: https://luciferdonghua.org

Catalogue search, series details and episode-list parsing are implemented from
public pages inspected. Stream extraction only returns a direct MP4/HLS URL if
one appears in the episode HTML. Inspected episode pages embed Dailymotion, so
playback is UNVERIFIED and likely unavailable through this module for those pages.

Manifest JSON and ZIP structure were checked. No Synthetiq runtime or playback
test was run. fetchv2 response compatibility may need adjustment in the app.
