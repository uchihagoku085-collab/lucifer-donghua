const BASE = "https://luciferdonghua.org";
function safeUrl(value) {
  try {
    const u = new URL(String(value || ""), BASE);
    return ["luciferdonghua.org", "www.luciferdonghua.org"].includes(u.hostname) &&
      ["https:", "http:"].includes(u.protocol) ? u.href : "";
  } catch (_) { return ""; }
}
function clean(s) {
  return String(s || "").replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ").replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&").replace(/&quot;/gi, '"')
    .replace(/&#0*39;|&apos;/gi, "'").replace(/\s+/g, " ").trim();
}
async function getText(url) {
  const target = safeUrl(url);
  if (!target) throw new Error("Unsupported Lucifer Donghua URL");
  const res = await fetchv2(target, { headers: { "User-Agent": "Mozilla/5.0" } });
  if (!res || (res.status && res.status >= 400)) throw new Error("Source request failed");
  let body = "";
  if (typeof res.text === "function") body = await res.text();
  else if (typeof res.body === "string") body = res.body;
  else if (typeof res.data === "string") body = res.data;
  if (!body) throw new Error("Empty source response");
  return body.slice(0, 2000000);
}
function links(html) {
  const out = [], re = /<a\b([^>]*?)href\s*=\s*(["'])(.*?)\2([^>]*)>([\s\S]*?)<\/a\s*>/gi;
  let m;
  while ((m = re.exec(html))) {
    const url = safeUrl(m[3].replace(/&amp;/g, "&"));
    const title = clean(m[5]);
    if (url && title) out.push({title, url});
  }
  const seen = new Set();
  return out.filter(x => !seen.has(x.url) && seen.add(x.url));
}
function isEpisode(s) { return /\b(?:episode|ep\.?|eps?)\s*[-:#]?\s*\d+/i.test(s); }
function epNum(s) { const m = s.match(/\b(?:episode|ep\.?|eps?)\s*[-:#]?\s*(\d+)/i); return m ? +m[1] : -1; }

globalThis.searchResults = async function(query) {
  const q = String(query || "").trim();
  const html = await getText(q ? BASE + "/?s=" + encodeURIComponent(q) : BASE + "/");
  return links(html).filter(x => !isEpisode(x.title) &&
    !/\/(?:about-us|privacy-policy|dmca|disclaimer|schedule|cast|network|genre|tag|category)\//i.test(x.url) &&
    x.url !== BASE + "/").slice(0, 30)
    .map(x => ({title:x.title, url:x.url, image:"", type:"video"}));
};

globalThis.extractDetails = async function(urlOrId) {
  const url = safeUrl(urlOrId);
  if (!url) throw new Error("A Lucifer Donghua series URL is required");
  const html = await getText(url);
  const m = html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i);
  const title = clean(m ? m[1] : "");
  const d = html.match(/<meta\b[^>]*name=["']description["'][^>]*content=["']([^"']*)["']/i);
  const im = html.match(/<img\b[^>]*src=["']([^"']+)["']/i);
  let image = ""; try { image = new URL(im ? im[1].replace(/&amp;/g,"&") : "", url).href; } catch (_) {}
  return {id:url, url, title:title || "Lucifer Donghua title",
    description:clean(d ? d[1] : ""), image, type:"video"};
};

globalThis.extractEpisodes = async function(seriesId) {
  const url = safeUrl(seriesId);
  if (!url) throw new Error("A Lucifer Donghua series URL is required");
  const html = await getText(url);
  return links(html).filter(x => isEpisode(x.title))
    .map(x => ({id:x.url, url:x.url, title:x.title, episode:epNum(x.title), type:"video"}))
    .sort((a,b) => b.episode - a.episode);
};

globalThis.extractStreamUrl = async function(episodeHref, lang) {
  const url = safeUrl(episodeHref);
  if (!url) throw new Error("A Lucifer Donghua episode URL is required");
  const html = await getText(url);
  const direct = html.match(/https?:\\?\/\\?\/[^"'\\\s<>]+?\.(?:m3u8|mp4)(?:\?[^"'\\\s<>]*)?/i);
  if (direct) {
    const candidate = direct[0].replace(/\\\//g, "/").replace(/&amp;/g, "&");
    if (/^https?:\/\//i.test(candidate)) return [{label:lang || "Default", url:candidate}];
  }
  if (/(?:geo\.)?dailymotion\.com|dai\.ly/i.test(html))
    throw new Error("Episode embeds Dailymotion; no verified direct MP4/HLS stream is exposed.");
  throw new Error("No verified direct MP4/HLS stream found on this episode page.");
};
